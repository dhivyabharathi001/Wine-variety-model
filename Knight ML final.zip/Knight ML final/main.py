# importing the necessary dependencies
from flask import Flask, render_template, request,jsonify
from flask_cors import CORS,cross_origin
import pickle

app = Flask(__name__) # initializing a flask app


@app.route('/predict',methods=['POST','GET']) # route to show the predictions in a web UI
@cross_origin()
def index():
    if request.method == 'POST':
        try:
            #  reading the inputs given by the user
            country =float(request.json['country'])
            designation = float(request.json['designation'])
            points = float(request.json['points'])
            price  = float(request.json['price'])
            province  = float(request.json['province'])
            region_1  = float(request.json['region_1'])
            region_2 = float(request.json['region_2'])
            winery = float(request.json['winery'])

            # Loading the saved models into memory
            filename_scaler = 'new_model.pickle'
            scaler_model = pickle.load(open(filename_scaler, 'rb'))

            # predictions using the loaded model file
            scaled_data=scaler_model.transform([[country,designation,points,price,province,region_1,region_2, winery]])
            prediction=loaded_model.predict(scaled_data)
            asc=['Pinot Noir','Chardonnay','Cabernet Sauvignon','Red Blend','Bordeaux-style Red Blend','Riesling',
             'Sauvignon Blanc','Syrah','Rosé','Merlot','Nebbiolo','Zinfandel','Sangiovese','Malbec','Portuguese Red',
             'White Blend','Sparkling Blend','Tempranillo','Rhône-style Red Blend','Pinot Gris','Champagne Blend',
             'Cabernet Franc','Grüner Veltliner','Portuguese White','Pinot Grigio','Bordeaux-style White Blend',
             'Gewürztraminer','Gamay']
            a=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28]
            c=asc[a.index(prediction[0])]
            print('Variety is', c)

            # showing the prediction results in a UI
            return jsonify(c)
        except Exception as e:
            print('The Exception message is: ',e)
            return jsonify('error: Something is wrong')
    # return render_template('results.html')



if __name__ == "__main__":
    #app.run(host='127.0.0.1', port=8001, debug=True)
   app.run(debug=True) # running the app
